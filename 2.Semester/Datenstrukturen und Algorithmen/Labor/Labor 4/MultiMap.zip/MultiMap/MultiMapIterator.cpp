#include "MultiMapIterator.h"
#include "MultiMap.h"

MultiMapIterator::MultiMapIterator(const MultiMap& c) : col(c), capacity(c.capacity) {
    currentIndex = 0;
    while(currentIndex < col.capacity && !col.occupiedIndices[currentIndex]){
        currentIndex++;
    }
}
//BC = Theta(1)
//WC = Theta(col.capacity)
//TC = O(col.capacity)

TElem MultiMapIterator::getCurrent() const{
    if(!valid()) {
        throw std::exception();
    }
    return col.elements[currentIndex];
}
//BC = WC = TC = Theta(1)

bool MultiMapIterator::valid() const {
    return currentIndex < col.capacity && col.occupiedIndices[currentIndex];
}
//BC = WC = TC = Theta(1)

void MultiMapIterator::next() {
    if(!valid()){
        throw std::exception();
    }
    do{
        currentIndex++;
    } while(currentIndex < col.capacity && !col.occupiedIndices[currentIndex]);

}
//BC = Theta(1)
//WC = Theta(col.capacity)
//TC = O(col.capacity)

void MultiMapIterator::first() {
    currentIndex = 0;
    while (currentIndex < col.capacity && !col.occupiedIndices[currentIndex]) {
        currentIndex++;
    }
}
//BC = WC = TC = Theta(1)