#include "MultiMap.h"
#include "MultiMapIterator.h"
#include <exception>
#include <iostream>

using namespace std;


MultiMap::MultiMap() {
    capacity = 4;
    initialCapacity = capacity;
    sizeofarray = 0;
    elements = new TElem [capacity];
    for(int i = 0; i < capacity; i++) {
        elements[i] = NULL_TELEM;
    }
    occupiedIndices = new bool[capacity];
    for (int i = 0; i < capacity; i++) {
        occupiedIndices[i] = false;
    }

}

//BC=WC=TC=Theta(capacity)

void MultiMap::add(TKey c, TValue v) {
    //cout<<"Adding "<<c<<" "<<v<<" size "<<size()<<endl;
    int initialIndex = hash1(c) % capacity;
    int step = hash2(c) % capacity;

    int currentIndex = initialIndex;
    int visitedCount = 0;
    bool repeatedInitialIndex = false;

    do {
        if (!occupiedIndices[currentIndex]) {
            //cout << "Adding key " << c << " at index " << currentIndex << endl;
            //cout << "Current capacity: " << capacity << endl;

            //cout<<endl;

            elements[currentIndex] = TElem(c, v);
            occupiedIndices[currentIndex] = true;
            sizeofarray++;
            return;
        }

        currentIndex = (currentIndex + step) % capacity;

        if (currentIndex == initialIndex) {
            repeatedInitialIndex = true;
        }

        visitedCount++;
    } while ((visitedCount < capacity));

    if(repeatedInitialIndex) {
        int newCapacity = capacity * 2;
        TElem* newElements = new TElem[newCapacity];
        bool* newOccupiedIndices = new bool[newCapacity];

        //cout << "Resizing MultiMap to capacity: " << newCapacity << endl;

        for (int i = 0; i < newCapacity; i++) {
            newElements[i] = NULL_TELEM;
            newOccupiedIndices[i] = false;
        }

        for (int i = 0; i < capacity; i++) {
            if (occupiedIndices[i]){
                int newIndex = hash1(elements[i].first) % newCapacity;
                int newStep = hash2(elements[i].first) % newCapacity;

                while (newOccupiedIndices[newIndex]) {
                    newIndex = (newIndex + newStep) % newCapacity;
                }
                newElements[newIndex] = elements[i];
                newOccupiedIndices[newIndex] = true;
                //cout << "Rehashed element " << elements[i].first << " to index " << newIndex << endl;
            }
        }

        delete[] elements;
        delete[] occupiedIndices;

        elements = newElements;
        occupiedIndices = newOccupiedIndices;
        capacity = newCapacity;

        initialIndex = hash1(c) % capacity;
        step = hash2(c) % capacity;
        currentIndex = initialIndex;
        visitedCount = 0;

        do {
            //cout<<capacity<<" "<<currentIndex<<endl;
            if (!occupiedIndices[currentIndex]) {
                //cout << "Adding key " << c << " at index " << currentIndex << endl;
                //cout << "Current capacity: " << capacity << endl;
                elements[currentIndex] = TElem(c, v);
                occupiedIndices[currentIndex] = true;
                sizeofarray++;
                return;
            }

            currentIndex = (currentIndex + step) % capacity;

            if (currentIndex == initialIndex) {
                repeatedInitialIndex = true;
            }

            visitedCount++;
        } while ((visitedCount < capacity));
    }
}
//BC = Theta(1)(when the first tryed index is empty and it can assign the pair to it)
//WC = Theta(capacity) (resize)
//TC = O(capacity)


bool MultiMap::remove(TKey c, TValue v) {
    int index = hash1(c) % capacity;
    int step = hash2(c) % capacity;
    int visitedIndices = 0;

    do {
        if(elements[index].first == c && elements[index].second == v) {
            elements[index] = NULL_TELEM;
            occupiedIndices[index] = false;
            sizeofarray--;
            return true;
        }

        index = (index + step) % capacity;

        visitedIndices++;

    }while(visitedIndices< capacity);

    return false;
}
//BC = Theta(1)
//WC = Theta(capacity)
//TC = O(capacity)

std::vector<TValue> MultiMap::removeKey (TKey key){
    std::vector<TValue> result;

    int index = hash1(key) % capacity;
    int step = hash2(key) % capacity;
    int visitedIndices = 0;
    bool repeted = false;

    do {
        if(elements[index].first == key) {
            result.push_back(elements[index].second);
            elements[index] = NULL_TELEM;
            occupiedIndices[index] = false;
            sizeofarray--;
        }
        index = (index + step) % capacity;

        if(index == hash1(key) % capacity) {
            repeted = true;
        }

        visitedIndices++;
    }while(visitedIndices < capacity && !repeted);

    return result;

}
//BC = Theta(capacity)
//WC = Theta(capacity)
//TC = O(capacity)


std::vector<TValue> MultiMap::search(TKey c) const {
    std::vector<TValue> result;

    int index = hash1(c) % capacity;
    int step = hash2(c) % capacity;
    int visitedIndices = 0;
    bool repeatedInitialIndex = false;

    do {
        if(elements[index].first == c) {
            result.push_back(elements[index].second);
        }
        index = (index + step) % capacity;

        if (index == hash1(c) % capacity) {
            repeatedInitialIndex = true;
        }
        visitedIndices++;
    } while(visitedIndices < capacity && !repeatedInitialIndex);

    return result;
}
//BC = Theta(capacity)
//WC = Theta(capacity)
//TC = O(capacity)



int MultiMap::size() const {
    return sizeofarray;
}
//BC = WC = TC = Theta(1)


bool MultiMap::isEmpty() const {
    return sizeofarray == 0;
}
//BC = WC = TC = Theta(1)

MultiMapIterator MultiMap::iterator() const {
    return MultiMapIterator(*this);
}
//BC = WC = TC = Theta(1)


MultiMap::~MultiMap() {
    delete[] elements;
}
//BC = WC = TC = Theta(1)

