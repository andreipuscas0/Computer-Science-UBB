package org.example;

abstract public class Animal {
    private String name;

    abstract public Food prefferedFood();

    public void eat(Food food) {
        System.out.println(name + " is eating: " + food);
    }
    public String getName() {
        return name;
    }

    public Animal(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Animal{" +
                "name='" + name + '\'' +
                '}';
    }

    public void setName(String name) {
        this.name = name;
    }
}
