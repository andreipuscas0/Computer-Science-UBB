package org.example;

public class Dog extends Animal{
    @Override
    public Food prefferedFood() {
        return new DogFood("dog_food");
    }

    public Dog(String name) {
        super(name);
    }
}
