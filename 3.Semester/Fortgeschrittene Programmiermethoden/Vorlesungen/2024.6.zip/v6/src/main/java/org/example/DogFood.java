package org.example;

public class DogFood extends Food{
    public DogFood(String name) {
        super(name);
    }
}
