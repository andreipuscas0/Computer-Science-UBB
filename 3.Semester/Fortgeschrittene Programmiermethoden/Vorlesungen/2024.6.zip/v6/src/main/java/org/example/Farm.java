package org.example;

//Factory
public class Farm {
    Animal createAnimal(String type, String name) {
        if (type.equals("cat"))
                return new Cat(name);
        if (type.equals("dog"))
                return new Dog(name);

        throw new RuntimeException("No such animal");
    }
}

//Factory Method

abstract class FarmFactory {
    abstract Animal createAnimal(String name);
}

class DogFactory extends FarmFactory{

    @Override
    Animal createAnimal(String name) {
        return new Dog(name);
    }
}

class CatFactory extends FarmFactory {

    @Override
    Animal createAnimal(String name) {
        return new Cat(name);
    }
}