package org.example;

public class Cat extends Animal{
    @Override
    public Food prefferedFood() {
        return new CatFood("cat food");
    }

    public Cat(String name) {
        super(name);
    }
}
