package org.example;

public class CatFood extends Food{
    public CatFood(String name) {
        super(name);
    }
}
