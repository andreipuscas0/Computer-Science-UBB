package org.example;

public class Farmer {
//    public void feed (Animal animal, Food food) {
    public void feed (Animal animal) {
        //one solution: instanceof
//        animal.eat(food);
        animal.eat(animal.prefferedFood());
    }
}
