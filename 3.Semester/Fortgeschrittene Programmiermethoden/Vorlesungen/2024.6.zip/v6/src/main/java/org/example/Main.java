package org.example;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.nio.file.Paths;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
//        try {
//            // create object mapper instance
//            ObjectMapper mapper = new ObjectMapper();
//
//            // convert JSON string to Book object
//            Book[] books = mapper.readValue(Paths.get("book.json").toFile(), Book[].class);
//
//            // print book
//            for (Book book: books)
//                System.out.println(book);
//
//        } catch (Exception ex) {
//            ex.printStackTrace();
//        }

        Farm farm = new Farm();

        FarmFactory ff = new CatFactory();

        Animal dog = farm.createAnimal("dog", "vasile");
//        Animal cat = farm.createAnimal("cat", "cat");
        Animal cat = ff.createAnimal("cat");



        Farmer farmer = new Farmer();

//        farmer.feed(cat, new DogFood("branza"));
        farmer.feed(cat);
        farmer.feed(dog);


    }
}