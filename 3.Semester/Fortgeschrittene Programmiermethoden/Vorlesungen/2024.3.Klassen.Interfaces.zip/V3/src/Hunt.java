public interface Hunt {

    public void hunt();
}
