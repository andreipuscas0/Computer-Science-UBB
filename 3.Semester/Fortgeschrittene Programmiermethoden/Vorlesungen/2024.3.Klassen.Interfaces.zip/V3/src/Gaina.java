public class Gaina extends Animal{

    @Override
    public void speak() {
        System.out.printf("oac");
    }
}
