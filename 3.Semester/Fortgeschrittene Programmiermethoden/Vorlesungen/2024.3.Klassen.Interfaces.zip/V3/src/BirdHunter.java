public interface BirdHunter {

    public void hunt();
    public void fly();
}
