public class Pinguin extends Animal implements Hunt {
    private String name;

    public Pinguin(String name) {
        this.name = name;
    }

    @java.lang.Override
    public java.lang.String toString() {
        return "Pinguin{" +
                "name='" + name + '\'' +
                '}';
    }

    public void speak() {
        System.out.printf("ug");
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void hunt(){
        System.out.printf("Pinguin::Fishing");
    }
}
