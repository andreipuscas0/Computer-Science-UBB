public class Eagle extends Animal implements Hunt, Fly{
    private String name;

    @Override
    public String toString() {
        return "Eagle{" +
                "name='" + name + '\'' +
                '}';
    }

    public void hunt() {
        System.out.printf("Eagle::fly");
    }

    @Override
    public void speak() {
        System.out.printf("bbb");
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Eagle(String name) {
        this.name = name;
    }

    @Override
    public void fly() {
        System.out.printf("Eagle::flying");
    }
}
