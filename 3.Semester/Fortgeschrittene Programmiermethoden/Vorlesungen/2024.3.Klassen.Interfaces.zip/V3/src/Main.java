//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {

    public static void hunters(Hunt hunter) {
        hunter.hunt();
    }
    public static void main(String[] args) {
        Pinguin pingu = new Pinguin("pingu");
        pingu.hunt();

        Eagle egl = new Eagle("Ion");
        egl.hunt();

        Gaina g = new Gaina();
        //g.hunt();

        g.speak();
        pingu.speak();
        egl.speak();

        egl.fly();

        hunters(egl);
        hunters(pingu);
    }
}