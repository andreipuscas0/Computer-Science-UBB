import java.util.*;

class Student implements Comparable<Student>{
    private String name;
    private int age;
    private int id;

    @Override
    public String toString() {
        return "Student{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", id=" + id +
                '}';
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public Student(String name, int age, int id) {
        this.name = name;
        this.age = age;
        this.id = id;
    }

    @Override
    public boolean equals(Object obj) {
        return id == ((Student) obj).getId();
    }

    public int getAge() {
        return age;
    }

    @Override
    public int compareTo(Student o) {
        return age - o.getAge();
    }
}

class Gruppe implements Iterable<Student>{
    private String name;
    private List<Student> students = new ArrayList<>();

    public Gruppe(String name) {
        this.name = name;
    }

    public void addStudent(Student student) {
        students.add(student);
    }

    public List<Student> getStudents() {
        return students;
    }

    @Override
    public Iterator<Student> iterator() {
        return new StudentIterator();
//        return new StudentIterator(this);
    }

    class StudentIterator implements Iterator<Student> {
        private int current = -1;
//        private Gruppe gruppe;

//        public StudentIterator(Gruppe gruppe) {
//            this.gruppe = gruppe;
//        }

        @Override
        public boolean hasNext() {
            return current != students.size() - 1;
//            return current != gruppe.getStudents().size() - 1;
        }

        @Override
        public Student next() {
            current += 1;
//            return gruppe.getStudents().get(current);
            return students.get(current);
        }
    }
}



class StudentComparator implements Comparator<Student> {

    @Override
    public int compare(Student o1, Student o2) {
        return o1.getName().compareTo(o2.getName());
    }
}

abstract class A {
    abstract void f ();
}

class T {
    private int x = 10;
    private static int y = 10;

    void f () {
        class X  {
            void f () {
                System.out.println("HERE##");
                System.out.println(x);
                System.out.println(y);
            }
        }

        X x = new X();
        x.f();
    }
    class V {
        void f () {
            System.out.println(x);
            System.out.println(y);
        }
    }

    static class U {
        void f() {
            System.out.println(y);
        }
    }
}

public class Main {
    public static void iter () {
        Gruppe gr = new Gruppe("777");
        Student bob = new Student("bob", 20, 101);
        Student dob = new Student("dob", 20, 101);

        gr.addStudent(bob);
        gr.addStudent(dob);

//        for (Student student: gr.getStudents()) {
//            System.out.println(student);
//        }

        for (Student student: gr) {
            System.out.println(student);
        }
    }
    public static void inner () {
        T t = new T();

        T.V v = t.new V();
        v.f();

        T.U u = new T.U();
        u.f();

        t.f();

        A a = new A() {
            @Override
            void f() {
                System.out.println("HERE^^");
            }
        };
        a.f();
    }
    public static void compare() {
        String s1 = "string";
        String s2 = "string";
        String s3 = new String("string");

        Integer i1 = 10;
        Integer i2 = 10;
//        Integer i2 = new Integer(10);

        System.out.println(s1 == s2);
        System.out.println(s1 == s3);
        System.out.println(s1.equals(s3));
        System.out.println(i1.equals(i2));
        System.out.println(i1 == i2);

        System.out.println("\n===========================\n");

        Student bob = new Student("bob", 20, 101);
        Student dob = new Student("dob", 20, 101);


        System.out.println(bob == dob);
        System.out.println(bob.equals(dob));

    }

    public static void sorters() {
        Student bob = new Student("zob", 25, 101);
        Student dob = new Student("dob", 21, 101);

        System.out.println(dob.compareTo(bob));

        List<Student> students = new ArrayList<>();

        students.add(bob);
        students.add(dob);

//        students.sort(new StudentComparator());
        students.sort(new Comparator<Student>() {
            @Override
            public int compare(Student o1, Student o2) {
                return o1.getName().compareTo(o2.getName());
            }
        });
        System.out.println(students);

        Collections.sort(students);
        System.out.println(students);
    }
    public static void main(String[] args) {
//        compare();
//        sorters();
//        inner();
        iter();
    }
}